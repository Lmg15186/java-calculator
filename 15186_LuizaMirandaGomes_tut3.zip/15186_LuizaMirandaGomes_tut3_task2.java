
// 15186_LuizaMirandaGomes_tut3_task2.java
// Task 2 - Another Land Vehicle (Car)

class Vehicle {
    String colour;
    double actualSpeed;

    public Vehicle(String colour, double actualSpeed) {
        this.colour = colour;
        this.actualSpeed = actualSpeed;
    }
}

class LandVehicle extends Vehicle {
    int numberWheels;

    public LandVehicle(String colour, double actualSpeed, int numberWheels) {
        super(colour, actualSpeed);
        this.numberWheels = numberWheels;
    }
}

class Car extends LandVehicle {
    String brand;
    String fuelType;
    int numberDoors;

    public Car(String colour, double actualSpeed, int numberWheels, String brand, String fuelType, int numberDoors) {
        super(colour, actualSpeed, numberWheels);
        this.brand = brand;
        this.fuelType = fuelType;
        this.numberDoors = numberDoors;
    }

    public void showInfo() {
        System.out.println("Car Details:");
        System.out.println("Colour: " + colour);
        System.out.println("Speed: " + actualSpeed + " km/h");
        System.out.println("Wheels: " + numberWheels);
        System.out.println("Brand: " + brand);
        System.out.println("Fuel Type: " + fuelType);
        System.out.println("Number of Doors: " + numberDoors);
    }
}

public class 15186_LuizaMirandaGomes_tut3_task2 {
    public static void main(String[] args) {
        Car myCar = new Car("Black", 180.0, 4, "Tesla", "Electric", 4);
        myCar.showInfo();
    }
}
