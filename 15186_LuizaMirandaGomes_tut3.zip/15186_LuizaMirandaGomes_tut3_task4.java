
// 15186_LuizaMirandaGomes_tut3_task4.java
// Task 4 - Inheritance from Circle (Cylinder and Sphere)

class Circle {
    double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    public double calculateArea() {
        return Math.PI * radius * radius;
    }
}

class Cylinder extends Circle {
    double height;

    public Cylinder(double radius, double height) {
        super(radius);
        this.height = height;
    }

    public double calculateVolume() {
        return calculateArea() * height;
    }

    public void showCharacteristics() {
        System.out.println("Cylinder - Radius: " + radius + ", Height: " + height);
        System.out.println("Base Area: " + calculateArea());
        System.out.println("Volume: " + calculateVolume());
    }
}

class Sphere extends Circle {
    public Sphere(double radius) {
        super(radius);
    }

    public double calculateVolume() {
        return (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
    }

    public void showCharacteristics() {
        System.out.println("Sphere - Radius: " + radius);
        System.out.println("Surface Area: " + 4 * calculateArea());
        System.out.println("Volume: " + calculateVolume());
    }
}

public class 15186_LuizaMirandaGomes_tut3_task4 {
    public static void main(String[] args) {
        Cylinder cylinder = new Cylinder(7.0, 10.0);
        cylinder.showCharacteristics();

        System.out.println();

        Sphere sphere = new Sphere(7.0);
        sphere.showCharacteristics();
    }
}
