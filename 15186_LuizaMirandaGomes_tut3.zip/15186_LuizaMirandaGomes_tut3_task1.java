
// 15186_LuizaMirandaGomes_tut3_task1.java
// Task 1 - Class and Inheritance

class Vehicle {
    String colour;
    double actualSpeed;

    public Vehicle(String colour, double actualSpeed) {
        this.colour = colour;
        this.actualSpeed = actualSpeed;
    }

    public void showInfo() {
        System.out.println("Colour: " + colour);
        System.out.println("Actual Speed: " + actualSpeed + " km/h");
    }
}

class LandVehicle extends Vehicle {
    int numberWheels;

    public LandVehicle(String colour, double actualSpeed, int numberWheels) {
        super(colour, actualSpeed);
        this.numberWheels = numberWheels;
    }

    @Override
    public void showInfo() {
        super.showInfo();
        System.out.println("Number of Wheels: " + numberWheels);
    }
}

class Bicycle extends LandVehicle {
    int numberGears;
    int actualGear;
    String frameMaterial;
    int numberCogsFront;
    int numberCogsBack;

    public Bicycle(String colour, double actualSpeed, int numberWheels, int numberGears,
                   int actualGear, String frameMaterial, int numberCogsFront, int numberCogsBack) {
        super(colour, actualSpeed, numberWheels);
        this.numberGears = numberGears;
        this.actualGear = actualGear;
        this.frameMaterial = frameMaterial;
        this.numberCogsFront = numberCogsFront;
        this.numberCogsBack = numberCogsBack;
    }

    @Override
    public void showInfo() {
        super.showInfo();
        System.out.println("Number of Gears: " + numberGears);
        System.out.println("Actual Gear: " + actualGear);
        System.out.println("Frame Material: " + frameMaterial);
        System.out.println("Front Cogs: " + numberCogsFront);
        System.out.println("Back Cogs: " + numberCogsBack);
    }
}

public class 15186_LuizaMirandaGomes_tut3_task1 {
    public static void main(String[] args) {
        Bicycle bike = new Bicycle("Red", 25.5, 2, 21, 5, "Carbon", 3, 7);
        bike.showInfo();
    }
}
