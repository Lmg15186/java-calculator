
// 15186_LuizaMirandaGomes_tut3_task3.java
// Task 3 - Circle Class

public class 15186_LuizaMirandaGomes_tut3_task3 {
    double radius;

    public 15186_LuizaMirandaGomes_tut3_task3(double radius) {
        this.radius = radius;
    }

    public double calculateDiameter() {
        return 2 * radius;
    }

    public double calculateCircumference() {
        return 2 * Math.PI * radius;
    }

    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    public void showCharacteristics() {
        System.out.println("Radius: " + radius);
        System.out.println("Diameter: " + calculateDiameter());
        System.out.println("Circumference: " + calculateCircumference());
        System.out.println("Area: " + calculateArea());
    }

    public static void main(String[] args) {
        15186_LuizaMirandaGomes_tut3_task3 circle = new 15186_LuizaMirandaGomes_tut3_task3(15.5);
        circle.showCharacteristics();
    }
}
