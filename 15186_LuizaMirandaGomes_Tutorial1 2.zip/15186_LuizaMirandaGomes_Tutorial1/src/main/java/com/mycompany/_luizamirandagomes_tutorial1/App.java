package com.mycompany._luizamirandagomes_tutorial1;

import javax.swing.JOptionPane;

public class App {

    public static void main(String[] args) {
        sumTwoNumbers();
        showFullName();
        calculateAverage();
    }

    
    /*-----------------------Task 1 ------------------------*/
    static void sumTwoNumbers() {
        String firstValue = JOptionPane.showInputDialog("Enter the first number:");
        String secondValue = JOptionPane.showInputDialog("Enter the second number:");

        int n1 = Integer.parseInt(firstValue);
        int n2 = Integer.parseInt(secondValue);

        int sum = n1 + n2;

        JOptionPane.showMessageDialog(null, "The sum is: " + sum);
    }
    
/*------------------Task2--------------------*/
    
    static void showFullName() {
        String firstName = JOptionPane.showInputDialog("Enter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");

        String fullName = firstName + " " + lastName;

        JOptionPane.showMessageDialog(null, "Your full name is: " + fullName);
    }
    
    
/*--------------------Task3---------------------*/
    
    static void calculateAverage() {
        String value1 = JOptionPane.showInputDialog("Enter the first number:");
        String value2 = JOptionPane.showInputDialog("Enter the second number:");
        String value3 = JOptionPane.showInputDialog("Enter the third number:");

       int n1 = Integer.parseInt(value1);
       int n2 = Integer.parseInt(value2);
       int n3 = Integer.parseInt(value3);

int average = (n1 + n2 + n3) / 3;

JOptionPane.showMessageDialog(null, "The average is: " + average);
    }
}
