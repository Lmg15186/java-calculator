/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assessment1;



import javax.swing.JOptionPane;

public class Assessment1 {

    // Task 1: Converter Fahrenheit para Celsius
    public static void task1() {
        String input = JOptionPane.showInputDialog("Enter temperature in Fahrenheit:");
        double fahrenheit = Double.parseDouble(input);
        double celsius = (fahrenheit - 32) * 5 / 9;
        JOptionPane.showMessageDialog(null, fahrenheit + " F = " + celsius + " C");
    }

    // Task 2: Converter nota em conceito
    public static void task2() {
        String input = JOptionPane.showInputDialog("Enter your exam mark:");
        int mark = Integer.parseInt(input);
        String grade;

        if (mark < 50) grade = "FAIL";
        else if (mark <= 64) grade = "PASS";
        else if (mark <= 74) grade = "CREDIT";
        else if (mark <= 84) grade = "DISTINCTION";
        else grade = "HIGH DISTINCTION";

        JOptionPane.showMessageDialog(null, "Your grade is: " + grade);
    }

    // Task 3: Cidadania e idade para habilitação
    public static void task3() {
        String citizen = JOptionPane.showInputDialog("Are you an Australian citizen? (YES/NO)");

        if (citizen.equalsIgnoreCase("YES")) {
            String inputAge = JOptionPane.showInputDialog("Enter your age:");
            int age = Integer.parseInt(inputAge);

            if (age >= 16) {
                JOptionPane.showMessageDialog(null, "You can apply for a driving license.");
                                                                }
                                                            } else {
                                                                JOptionPane.showMessageDialog(null, "You cannot apply for a driving license.");
                                                            }
                                                        }
                                                    
                                                        // Task 4: Convers\u00e3o de temperatura escolhendo unidade
                                                        public static void task4() {
                                                            String unitCode = JOptionPane.showInputDialog("Enter unit code (F for Fahrenheit, C for Celsius):");
                                                    
                                                            if (unitCode.equalsIgnoreCase("F")) {
                                                                String input = JOptionPane.showInputDialog("Enter temperature in Fahrenheit:");
                                                                double fahrenheit = Double.parseDouble(input);
                                                                double celsius = (fahrenheit - 32) * 5 / 9;
                                                                JOptionPane.showMessageDialog(null, fahrenheit + " F = " + celsius + " C");
                                                            } else if (unitCode.equalsIgnoreCase("C")) {
                                                                String input = JOptionPane.showInputDialog("Enter temperature in Celsius:");
                                                                double celsius = Double.parseDouble(input);
                                                                double fahrenheit = (celsius * 9 / 5) + 32;
                                                                JOptionPane.showMessageDialog(null, celsius + " C = " + fahrenheit + " F");
                                                            } else {
                                                                JOptionPane.showMessageDialog(null, "Invalid unit code. Please enter F or C.");
                                                            }
                                                        }
                                                    
                                                        // Menu principal
                                                        public static void main(String[] args) {
                                                            String menu = "Choose a task:\\n1 - Fahrenheit to Celsius\\n2 - Exam Grade\\n3 - Driving License Check\\n4 - Temperature Conversion (F <-> C)";
                                                            String choice = JOptionPane.showInputDialog(menu);
                                                    
                                                            switch (choice) {
                                                                case "1" -> task1();
                                                                case "2" -> task2();
                                                                case "3" -> task3();
                                                                case "4" -> task4();
                                                                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
                                                            }
                                                        }
                                                                                 }
                       
