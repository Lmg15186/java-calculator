package com.mycompany.mavenproject1;

import javax.swing.JOptionPane;

public class main {

    public static void main(String[] args) {
        String option = JOptionPane.showInputDialog("""
                                                    Select the programme:
                                                    1 - Add two values
                                                    2 - Full name
                                                    3 - Average of three numbers
                                                    """);

        // O ideal é tratar o caso do usuário fechar a janela (retorna null)
        if (option != null) {
            switch (option) {
                case "1" -> addTwoValues();
                case "2" -> fullName();
                case "3" -> mediaThreeNumbers();
                default -> JOptionPane.showMessageDialog(null, "Invalid option!");
            }
        }
    }

    // Task 1
    public static void addTwoValues() {
        String input1 = JOptionPane.showInputDialog("Enter the first value:");
        String input2 = JOptionPane.showInputDialog("Enter the second value:");
        
        // Adicionando tratamento de erro para entradas inválidas
        try {
            double n1 = Double.parseDouble(input1);
            double n2 = Double.parseDouble(input2);
            double sum = n1 + n2;
            JOptionPane.showMessageDialog(null, "The sum is: " + sum);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input! Please enter numbers only.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Task 2
    public static void fullName() {
        String name = JOptionPane.showInputDialog("Enter your name:");
        String surname = JOptionPane.showInputDialog("Enter your surname:");
        JOptionPane.showMessageDialog(null, "Your full name is: " + name + " " + surname);
    }

    // Task 3
    public static void mediaThreeNumbers() {
        String input1 = JOptionPane.showInputDialog("Enter the first number:");
        String input2 = JOptionPane.showInputDialog("Enter the second number:");
        String input3 = JOptionPane.showInputDialog("Enter the third number:");

        // Adicionando tratamento de erro para entradas inválidas
        try {
            double n1 = Double.parseDouble(input1);
            double n2 = Double.parseDouble(input2);
            double n3 = Double.parseDouble(input3);
            double average = (n1 + n2 + n3) / 3;
            // CORREÇÃO: Adicionando a aspa que faltava
            JOptionPane.showMessageDialog(null, "The average is: " + average);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input! Please enter numbers only.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
