package com.mycompany._luizamirandagomes_tutorial1;

import javax.swing.JOptionPane;

public class App {

    public static void main(String[] args) {
        sumTwoNumbers();
        showFullName();
        calculateAverage();
    }

    
    /*-----------------------Task 1 ------------------------*/
    static void sumTwoNumbers() {
        String firstValue = JOptionPane.showInputDialog("Enter the first number:");
        String secondValue = JOptionPane.showInputDialog("Enter the second number:");

        int number1 = Integer.parseInt(firstValue);
        int number2 = Integer.parseInt(secondValue);

        int sum = number1 + number2;

        JOptionPane.showMessageDialog(null, "The sum is: " + sum);
    }
    
/*------------------Task2--------------------*/
    
    static void showFullName() {
        String firstName = JOptionPane.showInputDialog("Enter your first name:");
        String lastName = JOptionPane.showInputDialog("Enter your last name:");

        String fullName = firstName + " " + lastName;

        JOptionPane.showMessageDialog(null, "Your full name is: " + fullName);
    }
    
    
/*--------------------Task3---------------------*/
    
    static void calculateAverage() {
        String value1 = JOptionPane.showInputDialog("Enter the first number:");
        String value2 = JOptionPane.showInputDialog("Enter the second number:");
        String value3 = JOptionPane.showInputDialog("Enter the third number:");

        double number1 = Double.parseDouble(value1);
        double number2 = Double.parseDouble(value2);
        double number3 = Double.parseDouble(value3);

        double average = (number1 + number2 + number3) / 3;

        JOptionPane.showMessageDialog(null, "The average is: " + average);
    }
}
