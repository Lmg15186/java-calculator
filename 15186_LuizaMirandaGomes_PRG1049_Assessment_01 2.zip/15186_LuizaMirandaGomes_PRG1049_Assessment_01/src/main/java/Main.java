package prg1049_tutorial4;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Task 1: Abstract Class ===");
        Square square = new Square("Square", "Blue", 5);
        square.showInfo();

        System.out.println();
        Circle circle = new Circle("Circle", "Red", 3);
        circle.showInfo();

        System.out.println("\n=== Task 2: Interfaces ===");
        Rectangle rectangle = new Rectangle(4, 6);
        rectangle.showCharacteristics();

        System.out.println();
        Sphere sphere = new Sphere(4);
        sphere.showCharacteristics();

        System.out.println();
        Cylinder cylinder = new Cylinder(3, 7);
        cylinder.showCharacteristics();
    }
}

