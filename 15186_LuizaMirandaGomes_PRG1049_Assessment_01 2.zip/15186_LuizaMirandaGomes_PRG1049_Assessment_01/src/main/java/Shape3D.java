package prg1049_tutorial4;

public interface Shape3D {
    double calculateVolume();
    void showCharacteristics();
}
