package prg1049_tutorial4;

public class Circle extends Poly {
    private double radius;

    public Circle(String name, String colour, double radius) {
        super(name, colour);
        this.radius = radius;
    }

    @Override
    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    @Override
    public void showInfo() {
        super.showInfo();
        System.out.println("Radius: " + radius);
        System.out.println("Area: " + calculateArea());
    }
}
