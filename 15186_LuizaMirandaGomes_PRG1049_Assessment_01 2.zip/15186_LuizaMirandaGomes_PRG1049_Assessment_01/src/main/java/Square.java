package prg1049_tutorial4;

public class Square extends Poly {
    private double sideLength;

    public Square(String name, String colour, double sideLength) {
        super(name, colour);
        this.sideLength = sideLength;
    }

    @Override
    public double calculateArea() {
        return sideLength * sideLength;
    }

    @Override
    public void showInfo() {
        super.showInfo();
        System.out.println("Side length: " + sideLength);
        System.out.println("Area: " + calculateArea());
    }
}
