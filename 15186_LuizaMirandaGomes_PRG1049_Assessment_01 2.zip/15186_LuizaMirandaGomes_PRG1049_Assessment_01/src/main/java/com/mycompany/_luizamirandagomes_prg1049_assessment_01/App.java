/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany._luizamirandagomes_prg1049_assessment_01;

/**
 *
 * @author luizagomes
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
