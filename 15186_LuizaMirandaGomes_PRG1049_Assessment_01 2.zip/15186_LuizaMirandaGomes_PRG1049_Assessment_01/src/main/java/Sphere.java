package prg1049_tutorial4;

public class Sphere implements Shape3D {
    private double radius;

    public Sphere(double radius) {
        this.radius = radius;
    }

    @Override
    public double calculateVolume() {
        return (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
    }

    @Override
    public void showCharacteristics() {
        System.out.println("Sphere:");
        System.out.println("Radius: " + radius);
        System.out.println("Volume: " + calculateVolume());
    }
}
