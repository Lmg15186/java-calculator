package prg1049_tutorial4;

public class Cylinder implements Shape3D {
    private double radius;
    private double height;

    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

    @Override
    public double calculateVolume() {
        return Math.PI * radius * radius * height;
    }

    @Override
    public void showCharacteristics() {
        System.out.println("Cylinder:");
        System.out.println("Radius: " + radius + ", Height: " + height);
        System.out.println("Volume: " + calculateVolume());
    }
}
