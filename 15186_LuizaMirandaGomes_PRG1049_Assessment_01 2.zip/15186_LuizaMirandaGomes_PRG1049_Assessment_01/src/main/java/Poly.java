package prg1049_tutorial4;

public abstract class Poly {
    protected String name;
    protected String colour;

    public Poly(String name, String colour) {
        this.name = name;
        this.colour = colour;
    }

    public abstract double calculateArea();

    public void showInfo() {
        System.out.println("Shape: " + name);
        System.out.println("Colour: " + colour);
    }
}
