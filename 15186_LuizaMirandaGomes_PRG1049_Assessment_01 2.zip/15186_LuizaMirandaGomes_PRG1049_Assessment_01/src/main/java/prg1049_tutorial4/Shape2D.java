package prg1049_tutorial4;

public interface Shape2D {
    double calculateDiameter();
    double calculateCircumference();
    double calculateArea();
    void showCharacteristics();
}
