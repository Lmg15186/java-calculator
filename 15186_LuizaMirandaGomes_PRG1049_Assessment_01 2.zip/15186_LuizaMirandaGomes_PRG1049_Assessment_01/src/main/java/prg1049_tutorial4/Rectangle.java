package prg1049_tutorial4;

public class Rectangle implements Shape2D {
    private final double width;
    private final double height;

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    @Override
    public double calculateDiameter() {
        return Math.sqrt(width * width + height * height);
    }

    @Override
    public double calculateCircumference() {
        return 2 * (width + height);
    }

    @Override
    public double calculateArea() {
        return width * height;
    }

    @Override
    public void showCharacteristics() {
        System.out.println("Rectangle:");
        System.out.println("Width: " + width + ", Height: " + height);
        System.out.println("Area: " + calculateArea());
        System.out.println("Perimeter: " + calculateCircumference());
        System.out.println("Diagonal: " + calculateDiameter());
    }
}
