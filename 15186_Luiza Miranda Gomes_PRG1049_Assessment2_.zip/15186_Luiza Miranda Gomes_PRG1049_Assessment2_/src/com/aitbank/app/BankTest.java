package com.aitbank.app;

import com.aitbank.model.*;
import com.aitbank.atm.ATM;

public class BankTest {
    public static void main(String[] args) {
        System.out.println("=== Start Test AITBank (eg) ===");

        SavingsAccount s = new SavingsAccount("S001", "Alice", 1000.0, 1000.0, 0.0005);
        NetSavingsAccount n = new NetSavingsAccount("N001", "Bob", 2000.0, 500.0, 0.01);
        ChequeAccount c = new ChequeAccount("C001", "Carol", 500.0, false, 0.0);
        FixedAccount f = new FixedAccount("F001", "Dave", 10000.0, 12, 0.05);

        System.out.println("\n-- Deposit --");
        s.deposit(200);
        System.out.printf("Savings S001 expect balance 1200.00 -> %.2f%n", s.getBalance());

        System.out.println("\n-- Valid ATM withdrawal --");
        ATM.performWithdrawal(s, 170); // 100+50+20
        ATM.performWithdrawal(n, 30);  // invalid: does not allow 30

        System.out.println("\n-- Daily limit test --");
        boolean res = s.withdraw(2000); // greater than configured daily limit (1000)
        System.out.println("Withdrawal attempt exceeding limit (expected false): " + res);

        System.out.println("\n-- FixedAccount early withdrawal --");
        f.withdraw(100); // records earlyWithdrawal = true
        System.out.println("FixedAccount earlyWithdrawal (expected true): " + f.isEarlyWithdrawal());
        f.addInterest(); // should not apply interest
        System.out.printf("FixedAccount balance after addInterest (expected no interest): %.2f%n", f.getBalance());

        System.out.println("\n-- Applying interest to Savings and NetSavings --");
        s.addInterest(); // daily interest
        n.addInterest(); // monthly interest (simulated)
        System.out.printf("Savings new balance: %.2f%n", s.getBalance());
        System.out.printf("NetSavings new balance: %.2f%n", n.getBalance());

        System.out.println("\n=== End of Test ===");
    }
}
