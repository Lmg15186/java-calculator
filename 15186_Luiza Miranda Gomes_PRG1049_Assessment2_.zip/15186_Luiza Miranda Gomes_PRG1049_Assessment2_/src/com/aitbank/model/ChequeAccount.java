package com.aitbank.model;


public class ChequeAccount extends Account {
    private final boolean overdraftAllowed;
    private final double overdraftLimit; // maximum negative value allowed (e.g., -500)

    public ChequeAccount(String accountId, String ownerName, double initialBalance,
                         boolean overdraftAllowed, double overdraftLimit) {
        super(accountId, ownerName, initialBalance);
        this.overdraftAllowed = overdraftAllowed;
        this.overdraftLimit = overdraftAllowed ? -Math.abs(overdraftLimit) : 0.0;
    }

    @Override
    public boolean withdraw(double amount) {
        if (amount <= 0) return false;
        double balance = 0;
        double potentialBalance = balance - amount;
        if (!overdraftAllowed && potentialBalance < 0) return false;
        if (overdraftAllowed && potentialBalance < overdraftLimit) return false;
        balance = potentialBalance;
        return true;
    }

    public void addInterest() {
        // ChequeAccount does not earn interest — empty implementation
    }
}
