package com.aitbank.model;
 

public class NetSavingsAccount extends Account {
    private final double dailyWithdrawalLimit;
    private final double interestRateMonthly; // ex: 0.01 = 1% ao mês

    public NetSavingsAccount(String accountId, String ownerName, double initialBalance,
                             double dailyWithdrawalLimit, double interestRateMonthly) {
        super(accountId, ownerName, initialBalance);
        this.dailyWithdrawalLimit = dailyWithdrawalLimit;
        this.interestRateMonthly = interestRateMonthly;
    }

    public double getWithdrawalLimit() { return dailyWithdrawalLimit; }

    @Override
    public boolean withdraw(double amount) {
        if (amount > dailyWithdrawalLimit) return false;
        return super.withdraw(amount);
    }

    /**
     *
     */
    @Override
    public void addInterest() {
        if (interestRateMonthly > 0) {
            balance += balance * interestRateMonthly;
        }
    }
}
