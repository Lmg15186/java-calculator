package com.aitbank.model;


public class SavingsAccount extends Account {
    private double dailyWithdrawalLimit;
    private final double interestRateDaily; // eg: 0.0005 = 0.05% per day
    private double balance;

    public SavingsAccount(String accountId, String ownerName, double initialBalance,
                          double dailyWithdrawalLimit, double interestRateDaily) {
        super(accountId, ownerName, initialBalance);
        this.dailyWithdrawalLimit = dailyWithdrawalLimit;
        this.interestRateDaily = interestRateDaily;
    }

    public void setWithdrawalLimit(double limit) {
        if (limit >= 0) this.dailyWithdrawalLimit = limit;
    }

    public double getWithdrawalLimit() { return dailyWithdrawalLimit; }


    public boolean withdraw(double amount) {
        if (amount > dailyWithdrawalLimit) return false;
        return super.withdraw(amount);
    }



    public void addInterest() {
        if (interestRateDaily > 0) {
            balance += balance * interestRateDaily;
        }
    }
}
