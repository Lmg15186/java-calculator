package com.aitbank.model;


public class FixedAccount extends Account {
    private boolean earlyWithdrawal;
    private final double interestRateFixed; // taxa para o período do contrato (ex: 0.05 = 5%)
    private double balance;

    public FixedAccount(String accountId, String ownerName, double initialBalance,
                        int contractPeriodMonths, double interestRateFixed) {
        super(accountId, ownerName, initialBalance);
        Math.max(0, contractPeriodMonths);
        this.interestRateFixed = interestRateFixed;
        this.earlyWithdrawal = false;
    }

    public boolean isEarlyWithdrawal() { return earlyWithdrawal; }

    @Override
    public boolean withdraw(double amount) {
        // Permitimos saque mas registramos retirada antecipada
        boolean result = super.withdraw(amount);
        if (result) earlyWithdrawal = true;
        return result;
    }

    public void addInterest() {
        // Aplica juros somente se não houve retirada antecipada
        if (!earlyWithdrawal && interestRateFixed > 0) {
            balance += balance * interestRateFixed;
        }
    }
}
