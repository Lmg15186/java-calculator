package com.aitbank.atm;

import com.aitbank.model.Account;


public class ATM {
    private static final int[] SUPPORTED_NOTES = {100, 50, 20};

   
    public static boolean validateNotes(int amount) {
        if (amount <= 0) return false;
       
        for (int n100 = amount / 100; n100 >= 0; n100--) {
            int restAfter100 = amount - n100 * 100;
            for (int n50 = restAfter100 / 50; n50 >= 0; n50--) {
                int rest = restAfter100 - n50 * 50;
                if (rest % 20 == 0) {
                    return true;
                }
            }
        }
        return false;
    }

    
    public static boolean performWithdrawal(Account acc, int amount) {
        if (!validateNotes(amount)) {
            System.out.println("ATM: It is not possible to dispense " + amount + " notes 100,50,20.");
            return false;
        }
        boolean success = acc.withdraw(amount);
        if (success) {
            System.out.printf("ATM: Withdrawal of %d completed. New balance: %.2f%n", amount, acc.getBalance());
            return true;
        } else {
            System.out.println("ATM: Withdrawal failure — insufficient balance or account restriction");
            return false;
        }
    }
}

